package com.wipro.sales.main;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextField;
import com.toedter.calendar.JDateChooser;
import com.wipro.sales.service.Administrator;

public class SalesApplication {
    Administrator admin = new Administrator();
    JFrame f;
    JTable table, table1, table2;
    JTextField t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11;
    JDateChooser date;

    SalesApplication() {
        f = new JFrame("Stock Management");
        f.getContentPane().setBackground(Color.DARK_GRAY);
        f.setBounds(0, 0, 1220, 751);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.getContentPane().setLayout(null);

        JLabel lblProductId = new JLabel("Product ID:");
        lblProductId.setBounds(30, 50, 100, 20);
        f.getContentPane().add(lblProductId);

        t1 = new JTextField();
        t1.setBounds(150, 50, 200, 20);
        f.getContentPane().add(t1);
        t1.setColumns(10);

        JLabel lblProductName = new JLabel("Product Name:");
        lblProductName.setBounds(30, 80, 100, 20);
        f.getContentPane().add(lblProductName);

        t2 = new JTextField();
        t2.setBounds(150, 80, 200, 20);
        f.getContentPane().add(t2);
        t2.setColumns(10);

        JLabel lblQuantityOnHand = new JLabel("Quantity on Hand:");
        lblQuantityOnHand.setBounds(30, 110, 100, 20);
        f.getContentPane().add(lblQuantityOnHand);

        t3 = new JTextField();
        t3.setBounds(150, 110, 200, 20);
        f.getContentPane().add(t3);
        t3.setColumns(10);

        JLabel lblProductUnitPrice = new JLabel("Product Unit Price:");
        lblProductUnitPrice.setBounds(30, 140, 110, 20);
        f.getContentPane().add(lblProductUnitPrice);

        t4 = new JTextField();
        t4.setBounds(150, 140, 200, 20);
        f.getContentPane().add(t4);
        t4.setColumns(10);

        JButton btnAdd = new JButton("Add");
        btnAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Add functionality to add a product
            }
        });
        btnAdd.setBounds(150, 170, 89, 23);
        f.getContentPane().add(btnAdd);

        JButton btnDelete = new JButton("Delete");
        btnDelete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Add functionality to delete a product
            }
        });
        btnDelete.setBounds(250, 170, 89, 23);
        f.getContentPane().add(btnDelete);

        JButton btnViewSalesReport = new JButton("View Sales Report");
        btnViewSalesReport.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Add functionality to view sales report
            }
        });
        btnViewSalesReport.setBounds(150, 200, 200, 23);
        f.getContentPane().add(btnViewSalesReport);

        JButton btnExit = new JButton("Exit");
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        btnExit.setBounds(150, 230, 200, 23);
        f.getContentPane().add(btnExit);

        f.setVisible(true);
    }

    public static void main(String[] args) {
        new SalesApplication();
    }
}
