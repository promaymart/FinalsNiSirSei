# Inventory-Sales-System
Inventory and Sales Maintenance using Java as Frontend and Oracle as Backend 
